﻿using System;
using System.Windows;
using MahApps.Metro.Controls;

namespace LiteDbExplorer.Framework.Windows
{
    /// <summary>
    /// Interaction logic for BaseWindow.xaml
    /// </summary>
    public partial class BaseWindow : MetroWindow
    {
        public BaseWindow()
        {
            InitializeComponent();
        }
        
    }
}
