﻿using MahApps.Metro.Controls;

namespace LiteDbExplorer.Framework.Windows
{
    /// <summary>
    /// Interaction logic for BaseDialogWindow.xaml
    /// </summary>
    public partial class BaseDialogWindow : MetroWindow
    {
        public BaseDialogWindow()
        {
            InitializeComponent();
        }
    }
}
