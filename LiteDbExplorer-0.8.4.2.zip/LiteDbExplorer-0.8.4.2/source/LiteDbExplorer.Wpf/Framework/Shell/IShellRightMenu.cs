﻿using System.ComponentModel;

namespace LiteDbExplorer.Framework.Shell
{
    public interface IShellRightMenu : INotifyPropertyChanged
    {

    }
}