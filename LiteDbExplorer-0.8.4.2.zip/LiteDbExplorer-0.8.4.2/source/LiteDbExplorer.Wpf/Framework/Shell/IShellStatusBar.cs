﻿using System.ComponentModel;

namespace LiteDbExplorer.Framework.Shell
{
    public interface IShellStatusBar : INotifyPropertyChanged
    {

    }
}