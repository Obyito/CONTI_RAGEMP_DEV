﻿using System.ComponentModel;

namespace LiteDbExplorer.Framework.Shell
{
    public interface IShellMenu : INotifyPropertyChanged
    {

    }
}