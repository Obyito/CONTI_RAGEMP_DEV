﻿namespace LiteDbExplorer
{
    public class CmdlineCommands
    {
        public const string Open = "open";
        public const string New = "new";
        public const string Focus = "focus";
    }
}
