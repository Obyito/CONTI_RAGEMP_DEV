﻿using System.Windows.Controls;

namespace LiteDbExplorer.Modules.Help
{
    /// <summary>
    /// Interaction logic for ReleaseNotesView.xaml
    /// </summary>
    public partial class ReleaseNotesView : UserControl
    {
        public ReleaseNotesView()
        {
            InitializeComponent();
        }
    }
}
