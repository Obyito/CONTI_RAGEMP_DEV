﻿namespace LiteDbExplorer.Modules
{
    public class Fails
    {
        public const string Canceled = "CANCELED";
    }
}