﻿namespace LiteDbExplorer.Modules.DbDocument
{
    public interface IDocumentDetailView
    {
        void UpdateView(DocumentReference documentReference);
    }
}