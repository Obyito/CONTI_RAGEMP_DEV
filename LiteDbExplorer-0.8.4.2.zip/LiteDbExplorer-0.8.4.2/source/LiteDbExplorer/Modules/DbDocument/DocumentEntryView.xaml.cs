﻿using System.Windows.Controls;

namespace LiteDbExplorer.Modules.DbDocument
{
    /// <summary>
    /// Interaction logic for DocumentEntryView.xaml
    /// </summary>
    public partial class DocumentEntryView : UserControl
    {
        public DocumentEntryView()
        {
            InitializeComponent();
        }
    }
}
