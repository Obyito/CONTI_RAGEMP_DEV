﻿using Dragablz;

namespace LiteDbExplorer.Modules.Main
{
    public interface ITabablzControlHolder
    {
        TabablzControl TabsControl { get; }
    }
}