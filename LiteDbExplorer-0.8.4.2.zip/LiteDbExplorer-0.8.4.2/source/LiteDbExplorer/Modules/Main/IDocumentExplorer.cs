﻿using Caliburn.Micro;

namespace LiteDbExplorer.Modules.Main
{
    public interface IDocumentExplorer : IScreen
    {
        
    }
}