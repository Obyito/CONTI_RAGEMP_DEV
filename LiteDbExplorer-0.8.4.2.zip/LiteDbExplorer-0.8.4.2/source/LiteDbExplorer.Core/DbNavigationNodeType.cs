﻿namespace LiteDbExplorer
{
    public enum DbNavigationNodeType
    {
        Database,
        Collection,
        FileCollection
    }
}