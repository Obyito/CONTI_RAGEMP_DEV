﻿namespace LiteDbExplorer
{
    public interface IReferenceNode
    {
        string InstanceId { get; }
    }
}