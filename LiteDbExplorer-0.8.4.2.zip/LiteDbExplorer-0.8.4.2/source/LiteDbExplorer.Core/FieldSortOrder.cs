﻿namespace LiteDbExplorer
{
    public enum FieldSortOrder
    {
        Alphabetical,
        Original
    }
}