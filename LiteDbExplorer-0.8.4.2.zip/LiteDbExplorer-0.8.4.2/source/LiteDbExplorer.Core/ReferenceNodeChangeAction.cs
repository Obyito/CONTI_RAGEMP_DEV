﻿namespace LiteDbExplorer.Core
{
    public enum ReferenceNodeChangeAction
    {
        None = 0,
        Add = 1,
        Remove = 2,
        Update = 3,
        Close = 10
    }
}